sap.ui.define([
	"com/yash/HTML5Module/test/unit/controller/welcome.controller"
], function () {
	"use strict";
});
